package Robert;

import java.util.ArrayList;
import java.util.List;

public class Driver {
	
	//user name and password connect to database
	private static String USER_NAME = "root";
	private static String PASSWORD = "tcss445@dmin";
	private static String INPUT_FOLDER = "./input/";
	
	/**
	 * main method
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		dbInsert.clearData(USER_NAME, PASSWORD);
		
		//read bills
		List<List<String>> bills =  CSVUtils.parse(INPUT_FOLDER + "bills_Barkis.csv");
		
		//read entities
		List<List<String>> entities = CSVUtils.parse(INPUT_FOLDER + "JINKINS LAURIE .csv");
		dbInsert.insertDonations(USER_NAME, PASSWORD, entities, "JINKINS LAURIE");
		
		entities = CSVUtils.parse(INPUT_FOLDER + "orcuttedmund.csv");
		dbInsert.insertDonations(USER_NAME, PASSWORD, entities, "orcuttedmund");
		
		entities = CSVUtils.parse(INPUT_FOLDER + "STAMBAUGH MELANIE .csv");
		dbInsert.insertDonations(USER_NAME, PASSWORD, entities, "STAMBAUGH MELANIE");
		
		dbInsert.insertData(USER_NAME, PASSWORD, new ArrayList<List<String>>(), 
				new ArrayList<List<String>>(), new ArrayList<List<String>>(), bills);
		
		dbInsert.populateData(USER_NAME, PASSWORD);
	}
	
}
