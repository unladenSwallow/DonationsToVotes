package Robert;

import java.sql.*;
import java.util.List;
/*
 * Patrick Sanchez
 * TCSS 445A
 * A collection of functions and sample commands ot be included in 
 * the Donations2Votes project
 */
public class dbInsert {

	private static final String DATABASE_HOST = "localhost";
	private static final int DATABASE_PORT = 3306;
	private static final String DATABASE_NAME = "dotes2votes";
	private static int ID = 1; //id of entity
	
	//clear data of all tables
	public static void clearData(String username, String password) throws SQLException {
		
		// create this outside of our individual batches
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://" + DATABASE_HOST + ":" + DATABASE_PORT + "/" + DATABASE_NAME, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // temporarily disables foreign key checks when building the database
        Statement toggle = con.createStatement();
        toggle.execute("SET FOREIGN_KEY_CHECKS = 0;");

        Statement stmt = con.createStatement();     
        
        //delete database before inserting
        stmt.addBatch("delete from roles");
        stmt.addBatch("delete from entities");
        stmt.addBatch("delete from bills");
        stmt.addBatch("delete from keywords");
        stmt.addBatch("delete from votes");
        stmt.addBatch("delete from donations");
        
        stmt.executeBatch();
        
        //re-enable foreign key checks
        toggle.execute("SET FOREIGN_KEY_CHECKS = 1;");
        //close resources
        
        stmt.close();
        con.close();
	}
    /*
     * Connects to the local database and surrounds actions in a try
     * catch block
     * --------------------------------------------------------------
     */
    public static void insertData(String username, String password, List<List<String>> keywords, List<List<String>> roles, List<List<String>> votes, List<List<String>> bills)
            throws SQLException {
        // create this outside of our individual batches
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://" + DATABASE_HOST + ":" + DATABASE_PORT + "/" + DATABASE_NAME, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // temporarily disables foreign key checks when building the database
        Statement toggle = con.createStatement();
        toggle.execute("SET FOREIGN_KEY_CHECKS = 0;");

        Statement stmt = con.createStatement();         
                
        for (List<String> line: keywords){        	
        	updateKeywords(stmt,line.get(0),line.get(1));
        }
        
        for (List<String> line: roles){        	
        	updateRoles(stmt,line.get(0),line.get(1),line.get(2),line.get(3),line.get(4),line.get(5));
        }
        
        for (List<String> line: votes){        	
        	updateVotes(stmt,line.get(0),line.get(1),line.get(2),line.get(3));
        }
        
        for (List<String> line: bills){        	
        	updateBills(stmt,line.get(0),line.get(2), "-");
        }
        
        //run our batch of collected inserts
        stmt.executeBatch();
        
        //re-enable foreign key checks
        toggle.execute("SET FOREIGN_KEY_CHECKS = 1;");
        //close resources
        
        stmt.close();
        con.close();

    }

    /*
     * Connects to the local database and surrounds actions in a try
     * catch block
     * --------------------------------------------------------------
     */
    public static void insertDonations(String username, String password, List<List<String>> bills, String to)
            throws SQLException {
        // create this outside of our individual batches
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://" + DATABASE_HOST + ":" + DATABASE_PORT + "/" + DATABASE_NAME, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // temporarily disables foreign key checks when building the database
        Statement toggle = con.createStatement();
        toggle.execute("SET FOREIGN_KEY_CHECKS = 0;");

        Statement stmt = con.createStatement();         
        
        for (int i = 0; i < bills.size(); i++){        
        	
        	List<String> line = bills.get(i);
        	
        	String from = line.get(0);
        	if (from.length() > 32){
        		from = from.substring(0, 32);
        	}
        	
        	//check duplicate
        	boolean dup = false;
        	for (int j = i + 1; j < bills.size(); j++){
        		List<String> otherLine = bills.get(j);
        		String from2 = otherLine.get(0);
            	if (from2.length() > 32){
            		from2 = from2.substring(0, 32);
            	}
            	
        		if (from.equals(from2) && otherLine.get(2).equals(otherLine.get(2))){
        			dup = true;
        			break;
        		}
        	}
        	if (!dup){
        		updateEntities(stmt, ID, null, from, null);
        		
        		ID++; //next insert
        		
        		updateDonations(stmt, from, to, line.get(1), line.get(2));
        	}
        }
        
        updateEntities(stmt, ID, null, to, null);
        ID++; //next insert
        
        //run our batch of collected inserts
        stmt.executeBatch();
        
        //re-enable foreign key checks
        toggle.execute("SET FOREIGN_KEY_CHECKS = 1;");
        //close resources
        
        stmt.close();
        con.close();

    }
    //--------------------------------------------------------------
    //FUNCTIONS    
    
    /* 
     * A Function which populates one entry of the keywords Table
     * @pre A roles table exists within our database 
     * 
     * @param stmt Our prepared statement to hold the batch of inserts
     * 
     * @param bill The string representation of the bill name
     * 
     * @param key Te string repr of an internal keyword
     * 
     * @param redir String representation of our internal redirect
     * 
     * @return No Return
     * 
     * @post The input is inserted into the table
     * --------------------------------------------------------------
     * 
     */
    private static void updateBills(Statement st, String bill,
            String name, String summary)
                    throws SQLException {
        // set size equal to number of expected characters to minimize
        // reallocation
        StringBuilder sb = new StringBuilder(200);
        sb.append("insert into Bills (BILL_NAME,FullName,Summary) values(");
        sb.append("'");
        sb.append(bill);
        sb.append("','");
        sb.append(name);
        sb.append("','");
        sb.append(summary);
        sb.append("')");
        //included for test confirmation

        String result = sb.toString();
        System.out.println(result);

        st.addBatch(sb.toString());

    }    
    
    /* 
     * A Function which populates one entry of the donations Table
     * @pre A donations table exists within our database 
     * 
     * @param st Statement passed from our main handling method, this contains
     * all of the batch commands
     * 
     * @param from The string representation of an INT identifier for donator
     * 
     * @param to The string repr of an INT identifier of the donee
     * 
     * @param date String in YYYYMMDD format
     * 
     * @param decimal String decimal value of the donation
     * 
     * @return No Return
     * 
     * @post The input is inserted into the table
     * --------------------------------------------------------------
     * 
     */
    private static void updateDonations(Statement st, String from,
            String to, String date, String Amount)
                    throws SQLException {
        // set size equal to number of expected characters to minimize
        // reallocation
        StringBuilder sb = new StringBuilder(100);
        sb.append("insert into donations (FROM_ID,TO_ID,DonationDate,Amount) values('");
        sb.append(from.replace("'", "''"));
        sb.append("','");
        sb.append(to.replace("'", "''"));
        sb.append("','");
        sb.append(date);
        sb.append("',");
        sb.append(Amount);
        sb.append(")");
        String result = sb.toString();
        //included for test confirmation

        System.out.println(result);

        st.addBatch(sb.toString());

    }
    
    
    
    /* 
     * A Function which populates one entry of the keywords Table
     * @pre A roles table exists within our database 
     * 
     * @param stmt Our prepared statement to hold the batch of inserts
     * 
     * @param entid The string representation of ID int
     * 
     * @param rolid The string repr of an ID int for roles
     * 
     * @param name String representation of our entitiy name
     * 
     * @param party String representation of party name(see db for list)
     * 
     * @return No Return
     * 
     * @post The input is inserted into the table
     * --------------------------------------------------------------
     * 
     */
    private static void updateEntities(Statement st, int enID, String rolid, String name,String party)
                    throws SQLException {
        // set size equal to number of expected characters to minimize
        // reallocation
        StringBuilder sb = new StringBuilder(200);
        
        if (party != null){
        	sb.append("insert into entities (ENT_ID, ROLE_ID,EntityName,Party) values(");
        }else{
        	sb.append("insert into entities (ENT_ID, ROLE_ID,EntityName) values(");
        }
        sb.append(enID);
        
        if (rolid != null){
        	sb.append(",'" + rolid + ",'");
        }else{
        	sb.append(",NULL,'");
        }
        
        sb.append(name.replace("'", "''"));
        
        if (party != null){        
        	sb.append("','" + party + "')");
        }else{
        	sb.append("')");
        }
        //included for test confirmation

        String result = sb.toString();
        System.out.println(result);

        st.addBatch(sb.toString());

    }    
    
    /* 
     * A Function which populates one entry of the keywords Table
     * @pre A roles table exists within our database 
     * 
     * @param stmt Our prepared statement to hold the batch of inserts
     * 
     * @param bill The string representation of the bill name
     * 
     * @param key Te string repr of an internal keyword
     * 
     * @param redir String representation of our internal redirect
     * 
     * @return No Return
     * 
     * @post The input is inserted into the table
     * --------------------------------------------------------------
     * 
     */
    private static void updateKeywords(Statement st, String bill,
            String key)
                    throws SQLException {
        // set size equal to number of expected characters to minimize
        // reallocation
        StringBuilder sb = new StringBuilder(200);
        sb.append("insert into keywords (BILL_NAME,Keyword) values(");
        sb.append("'");
        sb.append(bill);
        sb.append("','");
        sb.append(key);
        sb.append("')");
        //included for test confirmation

        String result = sb.toString();
        System.out.println(result);

        st.addBatch(sb.toString());

    }
    
    /* 
     * A Function which populates one entry of the roles Table
     * @pre A roles table exists within our database 
     * 
     * @param from The string representation of an INT identifier for donator
     * 
     * @param to Te string repr of an INT identifier of the donee
     * 
     * @param date String in YYYYMMDD format
     * 
     * @param decimal String decimal value of the donation
     * 
     * @return No Return
     * 
     * @post The input is inserted into the table
     * --------------------------------------------------------------
     * 
     */
    private static void updateRoles(Statement st, String rolid,
            String type, String title, String chmbr,String dist,String descr)
                    throws SQLException {
        // set size equal to number of expected characters to minimize
        // reallocation
        StringBuilder sb = new StringBuilder(200);
        sb.append("insert into roles (ROLE_ID,Roletype,RoleTitle,Chamber,District,Description) values(");
        
        sb.append(rolid);
        sb.append(",'");
        sb.append(type);
        sb.append("','");
        sb.append(title);
        sb.append("','");
        sb.append(chmbr);
        sb.append("',");
        sb.append(dist);
        sb.append(",'");
        sb.append(descr);
        sb.append("')");
        //included for test confirmation

        String result = sb.toString();
        System.out.println(result);

        st.addBatch(sb.toString());

    }    
    
    
    /* 
     * A Function which populates one entry of the votes Table
     * 
     * @pre A votes table exists within our database 
     * 
     * @param polid The string representation of an INT identifier for polid
     * 
     * @param billname The string repr of the bill name
     * 
     * @param vote String repr of the enum for voting result
     * 
     * @param sponsor String repr of the sponsor boolean
     * 
     * @return No Return
     * 
     * @post The input is inserted into the table
     * --------------------------------------------------------------
     * 
     */
    private static void updateVotes(Statement st, String polid,
            String billname, String vote, String sponsor)
                    throws SQLException {
        // set size equal to number of expected characters to minimize
        // reallocation
        StringBuilder sb = new StringBuilder();
        sb.append("insert into votes (POL_ID,BILL_NAME,Vote,SPonsor) values (");
        sb.append(polid);
        sb.append(",'");
        sb.append(billname);
        sb.append("','");
        sb.append(vote);
        sb.append("','");
        sb.append(sponsor);
        sb.append("')");
        String result = sb.toString();
        //included for test confirmation
        System.out.println(result);

        st.addBatch(sb.toString());

    }
    
    //populate
	public static void populateData(String username, String password) throws SQLException {
		//show bills table
		// create this outside of our individual batches
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://" + DATABASE_HOST + ":" + DATABASE_PORT + "/" + DATABASE_NAME, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        Statement stmt = con.createStatement();
        
        System.out.println("-----------------------------------------------------------");
        
        //bills table
        System.out.println("Bills table");
        
        ResultSet rs = stmt.executeQuery("select * from bills");
        while (rs.next()){
        	System.out.println("Bill Name: " + rs.getString("BILL_NAME") + ", Full name: " + rs.getString("FullName"));        	
        }
        
        System.out.println("\nEntities table");
        rs = stmt.executeQuery("select * from entities");
        while (rs.next()){
        	System.out.println("Entity ID: " + rs.getInt("ENT_ID") + ", Entity name: " + rs.getString("EntityName"));
        }
        
        System.out.println("\nDonations table");
        rs = stmt.executeQuery("select * from donations");
        while (rs.next()){
        	System.out.println("FROM_ID: " + rs.getString("FROM_ID") + ", TO_ID: " + rs.getString("TO_ID")
        	 + ", DonationDate: " + rs.getDate("DonationDate") + ", Amount: " + rs.getDouble("Amount"));
        }
       
        //close resources        
        stmt.close();
        con.close();
	}

}
