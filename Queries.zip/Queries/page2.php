<?php
require_once("connectDb.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Bills</title>
  </head>
  <body>
    <form name="billform" id="billform" action="" method="post">
        Enter Bill Number: <input type="text" name="billNumber" id="billNumber"/>
        <button type="submit">Ok</button>
    </form>
    <p>
    <?php
        if(isset($_POST["billNumber"])){
            
            $billNumber = htmlspecialchars(stripslashes(trim($_POST["billNumber"])));
            if(!empty($billNumber)){
                $query = "select * from bills where BILL_NAME='$billNumber'";
                if ($result = $conn->query($query)) {
                    $rowsCount = $result->num_rows;
                    if($rowsCount==1){
                        $row = $result->fetch_array();
                    ?>
                    <table border="1">
                        <tr>
                            <th>Bill Number</th>
                            <th>Full Name</th>
                            <th>Summary</th>
                        </tr>
                        <tr>
                            <td><?php echo $row["BILL_NAME"];?></td>
                            <td><?php echo $row["FullName"];?></td>
                            <td><?php echo $row["Summary"];?></td>
                        </tr>
                    </table>
                    <?php
                    } else echo "Bill Number is not valid!";
                    $result->close();
                } else echo "Query does not work!";
            } else echo "Bill Number is not valid!";
        }
    ?>
    </p>
  </body>
</html>
