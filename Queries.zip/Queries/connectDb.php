<?php
$host = "localhost";
$user = "root";
$password = "";
$databaseName = "dotes2votes";

$conn = new mysqli($host, $user, $password);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$conn->select_db($databaseName);
?>