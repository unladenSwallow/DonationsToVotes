<?php
require_once("connectDb.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Zipcode</title>
  </head>
  <body>
    <form name="zipform" id="zipform" action="" method="post">
        Enter ZipCode: <input type="text" name="zipcode" id="zipcode"/>
        or politician first name <input type="text" name="firstname" id="firstname"/> and last name <input type="text" name="lastname" id="lname"/>
        <button type="submit">Ok</button>
    </form>
    <p>
    <?php
        if(isset($_POST["zipcode"])&&isset($_POST["firstname"])&&isset($_POST["lastname"])){
          $valid = false;
          if(trim($_POST["zipcode"])!=""){
              $zipcode = intval($_POST["zipcode"]);
              if($zipcode!=0){
                  $query = "select * from zipcodes where ZIPCODE=$zipcode";
                  if ($result = $conn->query($query)) {
                      $rowsCount = $result->num_rows;
                      if($rowsCount==1){
                          $row = $result->fetch_array();
                          $district = $row["DISTRICT"];
                          $valid = true;
                      } else echo "Zipcode is not valid!";
                  } else echo "Query does not work!";
              } else echo "Zipcode is not valid!";
          } else {
              $firstName = htmlspecialchars(stripslashes(trim($_POST["firstname"])));
              $lastName = htmlspecialchars(stripslashes(trim($_POST["lastname"])));
              if(empty($firstName)||empty($firstName)) echo "Politician name is not valid!";
              else{
                  $query = "select * from politicians where LOWER(PoliticianName) LIKE LOWER('%$lastName%$firstName%')";
                    if ($result = $conn->query($query)) {
                        $rowsCount = $result->num_rows;
                        if($rowsCount==1){
                            $row = $result->fetch_array();
                            $district = $row["DISTRICT"];
                            $valid = true;
                        } else echo "Politician name is not valid!";
                    } else echo "Query does not work!";
              }
          }
          if($valid){
              $query = "select * from politicians where DISTRICT=$district";
                    if ($result = $conn->query($query)) {
                        $rowsCount = $result->num_rows;
                        if($rowsCount>0){
                            ?>
                            <table border="1">
                              <tr>
                                <th>Politician Name</th>
                                <th>Chamber</th>
                                <th>Party</th>
                                <th>Cuckold</th>
                                <th>Votes</th>
                              </tr>
                            <?php
                            while($row = $result->fetch_array()){
                                $politicianId = $row["POL_ID"];
                                echo "<tr><td>".$row["PoliticianName"]."</td><td>".$row["Chamber"]."</td><td>".$row["Party"]."</td><td>".$row["Cuckold"]."</td><td>";
                                $query2 = "select * from votes,bills where votes.BILL_NAME=bills.BILL_NAME and POL_ID=$politicianId";
                                if ($result2 = $conn->query($query2)) {
                                  $rowsCount2 = $result2->num_rows;
                                  if($rowsCount2>0){
                                ?>
                                <table border="1">
                                  <tr>
                                    <th>Bill Name</th>
                                    <th>Bill Summary</th>
                                    <th>Vote</th>
                                    <th>Sponsor</th>
                                  </tr>
                                  <?php
                                    while($row2 = $result2->fetch_array()){
                                      echo "<tr><td>".$row2["BILL_NAME"]."</td><td>".$row2["Summary"]."</td><td>".$row2["Vote"]."</td><td>".$row2["Sponsor"]."</td></tr>";
                                    }
                                  ?>
                                </table>
                                <?php
                                  } else echo "No votes.";
                                } else echo "Query does not work!";
                                echo "</td></tr>";
                            }
                            ?>
                            </table>
                            <?php
                        } else echo "No politicans found for this district!";
                    } else echo "Query does not work!";
          }
        }
    ?>
    </p>
  </body>
</html>