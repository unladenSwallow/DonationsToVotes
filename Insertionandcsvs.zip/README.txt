Included are all of the files used to compile the database.  It should be noted that the original politicians.csv has entries which are not included in our donors files, which may cause issues.  This appears to be a data mismatch, as our politicians file was gathered early in the process


Sample Output from the driver, only using 1000 donation entries
as the full data set takes roughly 40 minutes:


Number of Zipcode Entries 1986
Time Elapsed: 504ms

Number of Location Entries 49
Time Elapsed: 71ms


Number of  Keyword Entries 20132
Time Elapsed: 4423ms

Number of Donor Entries 44626
Time Elapsed: 352284ms

Number of  Bill Entries 2394
Time Elapsed: 3180ms

Number of Politician Entries 339
Time Elapsed: 285ms

Number of Donation Entries 44626
Time Elapsed: 53112ms

Number of Vote Entries 122346
Time Elapsed: 5717ms

Total Runtime: 421789ms


Program Complete